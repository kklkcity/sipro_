<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct()
    {
       	parent::__construct();
        $this->load->model('user/m_profil');
        
        if($this->session->userdata('user_is_logged_in')=='')
        {
        $this->session->set_flashdata('msg3', "<div class='alert alert-danger'>
                                <button type='button' class='close' data-dismiss='alert'>x</button> 
                                <class='fa fa-thumbs-up'> Silahkan Login kembali! ");
        redirect('login');
        }  
    }

    Public function index()
    {
        if($this->session->userdata('user_is_logged_in'))
        {
            $id = $this->session->userdata('id');
        }
        $data['notifikasi'] = $this->m_profil->notifikasi($id);
        $data['result'] = $this->m_profil->ambil_user($id);
        $data['page'] = "Dashboard";
        $this->load->view('v_template', $data);
		$this->load->view('user/dashboard/v_dashboard', $data);
        $this->load->view('v_footer');
    }

    public function konfirmasi_pasangan(){
        if($this->session->userdata('user_is_logged_in'))
        {
            $id = $this->session->userdata('id');
        }

        $id_peminta = $this->input->post('id_peminta');
        $id_anak = $this->input->post('id_peminta');
        $jenis_permintaan = $this->input->post('jenis_permintaan');
        $status_permintaan = $this->input->post('status_permintaan_terima');

        if($jenis_permintaan=='Suami'){
            $id_suami = $this->input->post('id_diminta');
            $id_istri = $this->input->post('id_peminta');
        }elseif($jenis_permintaan=='Istri'){
            $id_suami = $this->input->post('id_peminta');
            $id_istri = $this->input->post('id_diminta');
        }elseif($jenis_permintaan=='Ayah'){
            $id_suami = $this->input->post('id_diminta');        
        }else{
            $id_istri = $this->input->post('id_diminta');        
        }

        $data = array(
            'id_suami' => $id_suami,
            'id_istri' => $id_istri
        );

        $data2 = array(
            'status_permintaan' => $status_permintaan
        );

        $this->db->insert('pernikahan', $data);
        $this->m_profil->update_permintaan($id_peminta, $id, $data2);       
        $this->session->set_flashdata('message', "<div class='alert alert-success'>
                                <button type='button' class='close' data-dismiss='alert'>x</button> 
                                <class='fa fa-thumbs-up'> Permintaan hubungan berhasil ditambah, Cek Profil Anda! ");
        redirect('user/dashboard');
    }

    public function konfirmasi_pasangan_tolak(){
        if($this->session->userdata('user_is_logged_in'))
        {
            $id = $this->session->userdata('id');
        }

        $id_peminta = $this->input->post('id_peminta');

        $data = array(
            'status_permintaan' => $this->input->post('status_permintaan_tolak')
        );

        $this->m_profil->update_permintaan($id_peminta, $data);        
        $this->session->set_flashdata('message1', "<div class='alert alert-success'>
                                <button type='button' class='close' data-dismiss='alert'>x</button> 
                                <class='fa fa-thumbs-up'> OOppss. Permintaan berhasil ditolak! ");
        redirect('user/dashboard');
    }

    public function cari_user()
    {
        if($this->session->userdata('user_is_logged_in'))
        {
            $id = $this->session->userdata('id');
        }
        $data['result'] = $this->m_profil->ambil_user($id);
        $data['user'] = $this->m_profil->ambil_user($id);
        $data['cari'] = $this->m_profil->search();
        $data['page'] = "Hasil Pencarian User";

        $this->load->view('v_template',$data);
        $this->load->view('user/cari/v_cari_hasil', $data);
        $this->load->view('v_footer');
        }
    
    public function detail_user()
    {
        if($this->session->userdata('user_is_logged_in'))
        {
            $id = $this->session->userdata('id');
        }
        $id_user = $this->input->post('id_user');
        $data['detail'] = $this->m_profil->detail_user($id_user);
        $data['result'] = $this->m_profil->ambil_user($id);
        $data['page'] = "Detail Profil User";

        $this->load->view('v_template',$data);
        $this->load->view('user/cari/v_cari_detail', $data);
        $this->load->view('v_footer');
    }
}

?>