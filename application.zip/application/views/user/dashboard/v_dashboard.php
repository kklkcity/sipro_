
    <!-- Full Width Column -->
    <div class="content-wrapper">
    <div class="container">
    
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <?php echo $page ?>
            <small> </small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    <div>
        <?php echo $this->session->flashdata('message') ?>
        <?php echo $this->session->flashdata('message1') ?>
    </div>

        <?php foreach ($notifikasi as $data) { 
            if($data->status_permintaan=='Belum') {
            ?>

            <div class='alert alert-danger callout'>
            <form action="<?php echo site_url('user/dashboard/konfirmasi_pasangan'); ?>" method="POST">
                <div class="box-body table-responsive">                   
                <button type='button' class='close' data-dismiss='alert'>x</button> 
                <class='fa fa-thumbs-up'>
                <h4>Pemberitahuan Permintaan</h4>
                <hr>
                Hai <?php echo ucfirst($this->session->userdata('nama_lengkap')); ?> kamu mendapat pemberitahuan permintaan.
                <?php echo $data->nama_lengkap; ?>
                meminta anda sebagai 
                <?php echo $data->jenis_permintaan; ?>.<br>
                Apakah anda ingin menerima?
                <br>
                <input type="hidden" class="form-control" name="id_peminta" value="<?php echo $data->id_peminta; ?>">
                <input type="hidden" class="form-control" name="id_diminta" value="<?php echo $data->id_diminta; ?>">
                <input type="hidden" class="form-control" name="jenis_permintaan" value="<?php echo $data->jenis_permintaan; ?>">
                <input type="hidden" class="form-control" name="status_permintaan_terima" value="Terima">
                <input type="hidden" class="form-control" name="id_nikah">
             
                <div class="form-group">
                        <div class="col-sm-offset-0 col-sm-1">
                            <button type="submit" class="btn btn-success">Terima</button>
                        </div>
                    </div>
                </form>
                <form action="<?php echo site_url('user/dashboard/konfirmasi_pasangan_tolak'); ?>" method="POST">
                <button type="submit" class="btn btn-warning" style="margin-left:15px">Tolak</button>
                <input type="hidden" class="form-control" name="id_peminta" value="<?php echo $data->id_peminta; ?>">
                <input type="hidden" class="form-control" name="status_permintaan_tolak" value="Tolak">
                </form>
           
            </div>
            </div>

        <?php }else{

            echo "";
            }
        } ?>

           



        <div class='alert alert-info callout'>
            <button type='button' class='close' data-dismiss='alert'>x</button> 
            <class='fa fa-thumbs-up'>
            <h4>Selamat Datang <?php echo ucfirst($this->session->userdata('nama_lengkap')); ?> !!!</h4>
            di Aplikasi SILSILAH KELUARGA
        </div>


        <div class="box box-default">
            <div class="box-header with-border">
                <h3 class="box-title">Blank Box</h3>
            </div>
        <div class="box-body">
        
        The great content goes here          

        </div>



        <!-- /.box-body -->
        </div>


        <!-- /.box -->
    </section>
    <!-- /.content -->
    </div>
    <!-- /.container -->
    </div>
    <!-- /.content-wrapper -->